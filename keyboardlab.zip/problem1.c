/*
 * STUDENT: (Type your name here)
 */

/*
 * KeyboardLab (c) 2021 Christopher A. Bohn
 */

/******************************************************************************
 * This code will output the equivalent of the following three lines of code
 * but will be accomplished without using the W key or the backslash key.
 *
 * printf("TO\tArchie\n");
 * printf("RE\tI Need a Working Keyboard\n\n");
 * printf("Please order a new keyboard for me. This one is broken.\n");
 ******************************************************************************/

#include <stdio.h>

int main() {
    /* WRITE THIS FUNCTION */
    return 0;
}
